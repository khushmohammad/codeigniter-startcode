# Easy-Number-Separator
Easy Number Separator is a simple jQuery plugin for Separate input numbers in textboxes
